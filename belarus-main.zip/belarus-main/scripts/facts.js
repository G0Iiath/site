document.addEventListener('DOMContentLoaded', function() {
    if (window.innerWidth <= 768) {
        addSidebarToggle();
    }
    // Обработчик изменения размера окна
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768 && !document.querySelector('.sidebar-toggle')) {
            addSidebarToggle();
        } else if (window.innerWidth > 768) {
            // Удаляем кнопку и показываем боковую панель на больших экранах
            const toggleButton = document.querySelector('.sidebar-toggle');
            const sidebar = document.querySelector('.sidebar');
            if (toggleButton) {
                toggleButton.remove();
            }
            if (sidebar) {
                sidebar.style.display = 'block'; // Возвращаем к нормальному состоянию
            }
        }
    });
});

function addSidebarToggle() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    // Проверяем, существует ли уже кнопка
    if (document.querySelector('.sidebar-toggle')) return;

    // Создаем кнопку для переключения боковой панели
    const toggleButton = document.createElement('button');
    toggleButton.className = 'sidebar-toggle';
    toggleButton.textContent = '☰';
    toggleButton.setAttribute('aria-label', 'Показать/скрыть навигацию');

    // Добавляем кнопку в начало body
    document.body.insertBefore(toggleButton, document.body.firstChild);

    // По умолчанию скрываем боковую панель на мобильных устройствах
    sidebar.style.display = 'none';

    // Обработчик клика по кнопке
    toggleButton.addEventListener('click', function() {
        if (sidebar.style.display === 'none' || sidebar.style.display === '') {
            sidebar.style.display = 'block';
            this.textContent = '✕';
        } else {
            sidebar.style.display = 'none';
            this.textContent = '☰';
        }
    });
}